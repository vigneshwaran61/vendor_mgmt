 // ── On page load: populate all three dropdowns ─────────────────────────
        $(document).ready(function () {
            BindVendorDDL();
        });
  

        // ── Dropdown binders ───────────────────────────────────────────────────
        function BindVendorDDL() {
         ExtendedAjaxCall(
    '/Transactions/GetVendors',
    null,
    'GET',
    function (res) {
        if (res.flag) {

            // Optional: clear + default option
            $('#ddlVendor').empty().append('<option value="">Select Vendor</option>');

            $.each(res.data, function (i, item) {
                $('#ddlVendor').append(
                    $('<option>', {
                        value: item.value,
                        text: item.text
                    })
                );
            });
        }
    },
    null,   // ⚠️ keep null to avoid wrapper "false flag = error" issue
    null,
    true,
    false   // no loader (lightweight dropdown)
);
        }

        // ── Get existing agreements for selected vendor ─────────────────────────
        function GetExistingAgreements() {
            var vendorCode = $('#ddlVendor').val();
            var vendorNm   = $('#ddlVendor option:selected').text();
            if (!vendorCode) {
                showMessage('Please select a vendor.', true);
                return;
            }
           ExtendedAjaxCall(
    '/Transactions/BindExistingAgreements?vendorCode=' + encodeURIComponent(vendorCode)
    + '&vendorNm=' + encodeURIComponent(""),
    null,
    'GET',
    function (res) {

        if (res.flag) {
            var html = '';

            $.each(res.data, function (i, row) {
                html += '<tr>'
                    + '<td>' + (row.f_VendorCode  || '') + '</td>'
                    + '<td>' + (row.f_VendorName  || '') + '</td>'
                    + '<td>' + (row.f_AgreementNo || '') + '</td>'
                    + '<td>' + (row.f_ServiceType || '') + '</td>'
                    + '<td>' + (row.f_year        || '') + '</td>'
                    + '<td><a href="javascript:void(0);" onclick="ViewPdf(\''
                        + (row.f_VendorCode || '') + '\','
                        + (row.f_RollingNo  || 0) + ','
                        + (row.f_SrNo       || 0) + ')">'
                        + (row.f_AgreementNo || 'View') + '</a></td>'
                    + '</tr>';
            });

            $('#tExistingAgreements').html(html);
            $('#idSecExistingAgreements').show();
            ClearMsg();

        } else {
            showMessage(res.msg || 'No agreement found.', true);
            $('#idSecExistingAgreements').hide();
        }
    },
    null,   // ⚠️ IMPORTANT: keep null (avoid false flag triggering error callback)
    null,
    true,
    true    // loader ON (this looks like a heavier grid call)
);
        }

  

        // ── PDF viewer ─────────────────────────────────────────────────────────
        function ViewPdf(vendorCode, rollingNo, srNo) {
            var url = '/Transactions/ViewPdf?vendorCode=' + encodeURIComponent(vendorCode)
                    + '&rollingNo=' + rollingNo + '&srNo=' + srNo;
            $('#pdfFrame').attr('src', url);
            $('#pdfViewerSection').show();
        }

        function closePdf() {
            $('#pdfViewerSection').hide();
            $('#pdfFrame').attr('src', '');
        }

        // ── Helpers ────────────────────────────────────────────────────────────
        function ResetForm() {
            $('#ddlVendor').val('');
            $('#ddlService').val('');
            $('#ddlYear').val('');
            $('#dtValidFrom').val('');
            $('#ddlMonths').val('0');
            $('#txtValidTo').val('');
            $('#txtCommercialReferNo').val('');
            $('#idSecExistingAgreements').hide();
            $('#pdfViewerSection').hide();
        }

        function ShowMsg(msg, type) {
            $('#divMsg').html('<div class="alert alert-' + type + '">' + msg + '</div>');
        }

        function ClearMsg() {
            $('#divMsg').html('');
}