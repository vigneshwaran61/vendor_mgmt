 // ── On page load: populate all three dropdowns ─────────────────────────
        $(document).ready(function () {
            BindVendorDDL();
            BindServiceDDL();
            BindYearDDL();

            // Initialise datepicker (Bootstrap datepicker)
            $('.datepicker').datepicker({
                format: 'dd/mm/yyyy',
                autoclose: true
            });

            // Recalculate Valid-To when date or months changes
            $('#dtValidFrom, #ddlMonths').on('change', function () {
                CalculateValidTo();
            });
        });

        // ── Dropdown binders ───────────────────────────────────────────────────
        function BindVendorDDL() {
            $.ajax({
                url: '/Transactions/GetVendors',
                type: 'GET',
                success: function (res) {
                    if (res.flag) {
                        $.each(res.data, function (i, item) {
                            $('#ddlVendor').append($('<option>', { value: item.value, text: item.text }));
                        });
                    }
                }
            });
        }

        function BindServiceDDL() {
            $.ajax({
                url: '/Transactions/GetServices',
                type: 'GET',
                success: function (res) {
                    if (res.flag) {
                        $.each(res.data, function (i, item) {
                            $('#ddlService').append($('<option>', { value: item.value, text: item.text }));
                        });
                    }
                }
            });
        }

        function BindYearDDL() {
            $.ajax({
                url: '/Transactions/GetYears',
                type: 'GET',
                success: function (res) {
                    if (res.flag) {
                        $.each(res.data, function (i, item) {
                            $('#ddlYear').append($('<option>', { value: item.value, text: item.text }));
                        });
                    }
                }
            });
        }

        // ── Get existing agreements for selected vendor ─────────────────────────
        function GetExistingAgreements() {
            var vendorCode = $('#ddlVendor').val();
            var vendorNm   = $('#ddlVendor option:selected').text();
            if (!vendorCode) {
                ShowMsg('Please select a vendor.', 'warning');
                return;
            }
            $.ajax({
                url: '/Transactions/BindExistingAgreements?vendorCode=' + encodeURIComponent(vendorCode)
                                                         + '&vendorNm=' + encodeURIComponent(""),
                type: 'GET',
                success: function (res) {
                    if (res.flag) {
                        var html = '';
                        $.each(res.data, function (i, row) {
                            html += '<tr>'
                                + '<td>' + (row.f_VendorCode  || '') + '</td>'
                                + '<td>' + (row.f_VendorName  || '') + '</td>'
                                + '<td>' + (row.f_AgreementNo || '') + '</td>'
                                + '<td>' + (row.f_ServiceType || '') + '</td>'
                                + '<td>' + (row.f_year        || '') + '</td>'
                                + '<td><a href="javascript:void(0);" onclick="ViewPdf(\''
                                    + (row.f_VendorCode || '') + '\','
                                    + (row.f_RollingNo  || 0) + ','
                                    + (row.f_SrNo       || 0) + ')">'
                                    + (row.f_AgreementNo || 'View') + '</a></td>'
                                + '</tr>';
                        });
                        $('#tExistingAgreements').html(html);
                        $('#idSecExistingAgreements').show();
                        ClearMsg();
                    } else {
                        ShowMsg(res.msg || 'No agreement found.', 'warning');
                        $('#idSecExistingAgreements').hide();
                    }
                },
                error: function () {
                    ShowMsg('Error retrieving agreements.', 'danger');
                }
            });
        }

        // ── Save agreement ─────────────────────────────────────────────────────
        function SaveAgreement() {
            var vendorCode = $('#ddlVendor').val();
            var serviceCode = $('#ddlService').val();
            var yearValue = $('#ddlYear').val();
            var validFrom = $('#dtValidFrom').val();
            var months = $('#ddlMonths').val();
            var commercialReferNo = $('#txtCommercialReferNo').val();
            var validTo =$('#txtValidTo').val();

            if (!vendorCode)     { ShowMsg('Please select a vendor.',  'warning'); return; }
            if (!serviceCode)    { ShowMsg('Please select a service.', 'warning'); return; }
            if (!yearValue)      { ShowMsg('Please select a year.',    'warning'); return; }
            if (!validFrom)      { ShowMsg('Please enter Valid From date.', 'warning'); return; }
            if (!months || months === '0') { ShowMsg('Please select months.', 'warning'); return; }

            var bo = {
                Vendor:            vendorCode,
                Service:           serviceCode,
                Year:              yearValue,
                ValidFrom:         validFrom,
                Months:            months,
                CommercialReferNo: commercialReferNo
            };

            $('#btnSave').prop('disabled', true).text('Saving...');

            $.ajax({
                url: '/Transactions/SaveAgreement',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(bo),
                success: function (res) {
                    if (res.flag) {
                        ShowMsg('Agreement saved successfully. Agreement Number: ' + (res.agreementNo || ''), 'success');
                        ResetForm();
                    } else {
                        ShowMsg(res.msg || 'Save failed.', 'danger');
                    }
                },
                error: function () {
                    ShowMsg('An error occurred while saving.', 'danger');
                },
                complete: function () {
                    $('#btnSave').prop('disabled', false).text('Save Agreement');
                }
            });
        }

        // ── Calculate valid-to via server (preserves business logic) ───────────
        function CalculateValidTo() {
            var validFrom = $('#dtValidFrom').val();
            var months    = $('#ddlMonths').val();
            if (validFrom && months && months !== '0') {
                $.ajax({
                    url: '/Transactions/CalculateValidTo?validFrom=' + encodeURIComponent(validFrom) + '&months=' + months,
                    type: 'GET',
                    success: function (data) {
                        if (data.success) {
                            $('#txtValidTo').val(data.validTo);
                        }
                    }
                });
            } else {
                $('#txtValidTo').val('');
            }
        }

        // ── PDF viewer ─────────────────────────────────────────────────────────
        function ViewPdf(vendorCode, rollingNo, srNo) {
            var url = '/Transactions/ViewPdf?vendorCode=' + encodeURIComponent(vendorCode)
                    + '&rollingNo=' + rollingNo + '&srNo=' + srNo;
            $('#pdfFrame').attr('src', url);
            $('#pdfViewerSection').show();
        }

        function closePdf() {
            $('#pdfViewerSection').hide();
            $('#pdfFrame').attr('src', '');
        }

        // ── Helpers ────────────────────────────────────────────────────────────
        function ResetForm() {
            $('#ddlVendor').val('');
            $('#ddlService').val('');
            $('#ddlYear').val('');
            $('#dtValidFrom').val('');
            $('#ddlMonths').val('0');
            $('#txtValidTo').val('');
            $('#txtCommercialReferNo').val('');
            $('#idSecExistingAgreements').hide();
            $('#pdfViewerSection').hide();
        }

        function ShowMsg(msg, type) {
            $('#divMsg').html('<div class="alert alert-' + type + '">' + msg + '</div>');
        }

        function ClearMsg() {
            $('#divMsg').html('');
        }