﻿

//var Api_settings_Page = {
//    //when publish the code comment above line
//    url: 'http://localhost:52204/',
//      // when publish the code on live server  remove comment above line
//   // url: 'http://app-it-p-ext-core.mfeka.com:2009/WA_EP_CORE_COMMON_USER_PROFILE/' //live
//     // when publish the code on UAT server  remove comment above line
//   //url: 'http://app-it-d-int-core.mfeka.com/WA_EP_CORE_COMMON_USER_PROFILE/'
    

//};

//var UserMst = {};
//UserMst.SapCode = '';
//UserMst.CreatedIP = '';
//UserMst.CreatedOn = null;
//UserMst.CreatedBy = '';
//UserMst.CreatedID = '';
//UserMst.CreatedType = '';
//UserMst.UpdatedIP = '';
//UserMst.UpdatedBy = '';
//UserMst.UpdatedOn = null;
//UserMst.SessionId = '';
//UserMst.FormId = '';
//UserMst.CreatedByUname = '';
//UserMst.UpdatedByUname = '';
//UserMst.FormIdCode = '';
//UserMst.UpdatedID = '';
//UserMst.UpdatedType = '';
//UserMst.Email = '';
//UserMst.Company_Code = '';

//function GetUserDtl() {
//    //url = "http://app-it-p-ext-core.mfeka.com:2009/WA_EP_CORE_COMMON_USER_PROFILE/Default/GetSessionInfo";
//    //url = Api_settings_Page.url + "Default/GetSessionInfo";
//     ExtendedAjaxCall('/Default/GetSessionInfo', null, 'GET', function (result) {
//    //ExtendedAjaxCall(url, null, 'GET', function (result) {
//        UserMst.SapCode = UserMst.UpdatedBy = UserMst.UpdatedID = UserMst.CreatedID = UserMst.CreatedBy = result.session.entity_SAPCode;
//        UserMst.UpdatedType = UserMst.CreatedType = result.session.entity_Type_Code;
//        UserMst.SessionId = result.session.sessionId;
//        UserMst.CreatedIP = UserMst.UpdatedIP = result.ip;
//         UserMst.UpdatedByUname = UserMst.CreatedByUname = result.session.entity_Name;
//         UserMst.FormIdCode = result.FormIdCode;//.formCode;
//         UserMst.FormId = result.formid;
//         UserMst.Email = result.session.entity_Email;
//         UserMst.Company_Code = result.session.entity_Company_Code;
//    }, null, null, false, true);
//}
