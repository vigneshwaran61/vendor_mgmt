   var _searchCtx = {};

    // ── On page load: populate Month dropdown ─────────────────────────────
    $(document).ready(function () {
        $.ajax({
            url: '/Reports/GetMonths',
            type: 'GET',
            success: function (res) {
                if (res.flag) {
                    $.each(res.data, function (i, item) {
                        $('#ddlMonth').append($('<option>', { value: item.value, text: item.text }));
                    });
                }
            }
        });
    });

    // ── Cascade: Month → Vendors ──────────────────────────────────────────
    function onMonthChange(month) {
        $('#trRate').hide();
        $('#trSearch').hide();
        $('#ddlVendor').html('<option value=""> -Select- </option>');
        $('#ddlPONo').html('<option value=""> -Select- </option>');
        if (!month) return;

        $.ajax({
            url: '/Reports/BindVendors?month=' + encodeURIComponent(month),
            type: 'GET',
            success: function (data) {
                $.each(data, function (i, v) {
                    $('#ddlVendor').append($('<option>', { value: v.value, text: v.text }));
                });
                $('#trRate').show();
            }
        });
    }

    // ── Cascade: Vendor → PO Numbers ─────────────────────────────────────
    function onVendorChange(vendorCode) {
        $('#trSearch').hide();
        $('#ddlPONo').html('<option value=""> -Select- </option>');
        if (!vendorCode) return;
        var month = $('#ddlMonth').val();

        $.ajax({
            url: '/Reports/BindPONumbers?month=' + encodeURIComponent(month) + '&vendorCode=' + encodeURIComponent(vendorCode),
            type: 'GET',
            success: function (data) {
                $.each(data, function (i, p) {
                    $('#ddlPONo').append($('<option>', { value: p.value, text: p.text }));
                });
                $('#trSearch').show();
            }
        });
    }

    // ── Search ────────────────────────────────────────────────────────────
    function SearchReport() {
        var month      = $('#ddlMonth').val();
        var vSel       = $('#ddlVendor');
        var poSel      = $('#ddlPONo');
        var vendorCode = vSel.val();
        var vendorText = vSel.find('option:selected').text();
        var poVal      = poSel.val();
        var poText     = poSel.find('option:selected').text();
        var rateSeq    = poText; 

        if (!month || !vendorCode || !poVal) {
            ShowMsg('Please select Month, Vendor and PO Number.', 'warning');
            return;
        }

        _searchCtx = {
            SelectedMonth:      month,
            SelectedVendorCode: vendorCode,
            SelectedVendorText: vendorText,
            SelectedPOValue:    poVal,
            SelectedPOText:     poText,
            SelectedPORateSeq:  rateSeq,
            DebitReason:        ''
        };

        $.ajax({
            url: '/Reports/Search',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(_searchCtx),
            success: function (res) {
                if (!res.flag) { ShowMsg(res.msg || 'No data found.', 'warning'); return; }

                ClearMsg();

                // Fill detail labels
                $('#lblHeader').text(res.header);
                var d = res.details;
                $('#lblPONo').text(d.poNumber);
                $('#lblRateRev').text(d.rateSequence);
                $('#lblPoEffectFrom').text(d.poEffectFrom);
                $('#lblPOEffectTo').text(d.poEffectTo);
                $('#lblVendorCode').text(d.vendorCode);
                $('#lblVendorName').text(d.vendorName);
                $('#lblResCount').text(d.noOfUnits);
                $('#lblMonthDays').text(d.totalMonthDays);
                $('#lblPayableDays').text(d.payableDays);
                $('#lblTotalWorkingDays').text(d.totalWorkingDays);

                // Fill totals
                $('#lblNet').text(res.totalCredit);
                $('#lblDebit').text(res.totalDebit);
                $('#lblDebitCompany').text(res.compDebit);
                $('#lblGrand').text(res.netPayable);
                $('#txtDebitReason').val(res.debitReason).prop('disabled', res.isGenerated);

                // Grid
                var html = '';
                $.each(res.gridRows, function (i, row) {
                    html += '<tr>'
                        + '<td>' + (row.f_ResourceName  || '') + '</td>'
                        + '<td>' + (row.f_GradeCode     || '') + '</td>'
                        + '<td>' + (row.f_GradeMonthlyPOValue  || '') + '</td>'
                        + '<td>' + (row.f_MaxFixedAmount        || '') + '</td>'
                        + '<td>' + (row.f_MaxVariablePercentage || '') + '</td>'
                        + '<td>' + (row.f_MaxVariableAmount     || '') + '</td>'
                        + '<td>' + (row.f_ActualVariablePercentage || '') + '</td>'
                        + '<td>' + (row.f_ActualVariableAmount   || '') + '</td>'
                        + '<td>' + (row.f_PayableDays            || '') + '</td>'
                        + '<td>' + (row.f_PresentWorkingDays     || '') + '</td>'
                        + '<td>' + (row.f_PaidDays               || '') + '</td>'
                        + '<td>' + (row.f_PerDayCost             || '') + '</td>'
                        + '<td>' + (row.f_CreditAmount           || '') + '</td>'
                        + '<td>' + (row.f_DebitResource          || '') + '</td>'
                        + '<td>' + (row.f_NetPayable             || '') + '</td>'
                        + '</tr>';
                });
                $('#tReportGrid').html(html);
                $('#tblReportGrid').show();

                // Action buttons
                BuildActionButtons(res.isGenerated, res.showCovering);

                $('#pnlDetails').show();
            },
            error: function () {
                ShowMsg('An error occurred while searching.', 'danger');
            }
        });
    }

    // ── Build Generate / Export buttons based on search result state ───────
    function BuildActionButtons(isGenerated, showCovering) {
        var html = '';
        if (!isGenerated) {
            html += '<button type="button" class="button" id="btnGenerate" onclick="GenerateReport()">Generate</button>&nbsp;';
        }
        if (isGenerated) {
            html += '<button type="button" class="button" id="btnExport" onclick="ExportInvoice()">Export To Invoice</button>&nbsp;';
            if (showCovering) {
                html += '<button type="button" class="button" id="btnExportCovering" onclick="ExportCovering()">Export To Covering Letter</button>';
            }
        }
        $('#divActions').html(html);
    }

    // ── Generate (AJAX) ───────────────────────────────────────────────────
    function GenerateReport() {
        _searchCtx.DebitReason = $('#txtDebitReason').val();
        $('#btnGenerate').prop('disabled', true).text('Processing...');
        $.ajax({
            url: '/Reports/Generate',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(_searchCtx),
            success: function (res) {
                if (res.flag) {
                    ShowMsg('Generated successfully. Proceed with Export!', 'success');
                    BuildActionButtons(true, res.hasCovering);
                } else {
                    ShowMsg(res.msg || 'Generate failed.', 'danger');
                    $('#btnGenerate').prop('disabled', false).text('Generate');
                }
            },
            error: function () {
                ShowMsg('An error occurred during Generate.', 'danger');
                $('#btnGenerate').prop('disabled', false).text('Generate');
            }
        });
    }

    // ── Export Invoice (standard form POST — file download) ───────────────
    function ExportInvoice() {
        FillExportForm('frmExportInvoice', 'hExp');
        $('#frmExportInvoice').submit();
    }

    // ── Export Covering Letter (standard form POST — file download) ────────
    function ExportCovering() {
        FillExportForm('frmExportCovering', 'hCov');
        $('#frmExportCovering').submit();
    }

    function FillExportForm(formId, prefix) {
        $('#' + prefix + 'Month').val(_searchCtx.SelectedMonth);
        $('#' + prefix + 'VendorCode').val(_searchCtx.SelectedVendorCode);
        $('#' + prefix + 'VendorText').val(_searchCtx.SelectedVendorText);
        $('#' + prefix + 'POValue').val(_searchCtx.SelectedPOValue);
        $('#' + prefix + 'POText').val(_searchCtx.SelectedPOText);
        $('#' + prefix + 'RateSeq').val(_searchCtx.SelectedPORateSeq);
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    function ShowMsg(msg, type) {
        $('#divMsg').html('<span style="color:' + (type === 'success' ? 'green' : type === 'warning' ? 'orange' : 'red')
            + '; font-family:Verdana; font-size:10pt;">' + msg + '</span>');
    }
    function ClearMsg() { $('#divMsg').html(''); } 
