   var _searchCtx = {};

    // ── On page load: populate Month dropdown ─────────────────────────────
  $(document).ready(function () {

    ExtendedAjaxCall(
        '/Reports/GetMonths',
        null,
        'GET',
        function (res) {
            if (res.flag) {
                $.each(res.data, function (i, item) {
                    $('#ddlMonth').append(
                        $('<option>', {
                            value: item.value,
                            text: item.text
                        })
                    );
                });
            }
        },
        null,   // no custom error handling needed
        null,   // no complete callback
        true,   // async
        false   // no loader (better UX for small dropdown)
    );

});

    // ── Cascade: Month → Vendors ──────────────────────────────────────────
    function onMonthChange(month) {
        $('#trRate').hide();
        $('#trSearch').hide();
        $('#ddlVendor').html('<option value=""> -Select- </option>');
        $('#ddlPONo').html('<option value=""> -Select- </option>');
        if (!month) return;

     ExtendedAjaxCall(
            '/Reports/BindVendors?month=' + encodeURIComponent(month),
            null,
            'GET',
            function (data) {
                // Optional: clear existing options first
                $('#ddlVendor').empty().append('<option value="">Select Vendor</option>');

                $.each(data, function (i, v) {
                    $('#ddlVendor').append(
                        $('<option>', {
                            value: v.value,
                            text: v.text
                        })
                    );
                });

                $('#trRate').show();
            },
            null,   // no custom error handler
            null,   // no complete callback
            true,   // async
            false   // no loader (dropdown case)
        );
    }

    // ── Cascade: Vendor → PO Numbers ─────────────────────────────────────
    function onVendorChange(vendorCode) {
        $('#trSearch').hide();
        $('#ddlPONo').html('<option value=""> -Select- </option>');
        if (!vendorCode) return;
        var month = $('#ddlMonth').val();

            ExtendedAjaxCall(
        '/Reports/BindPONumbers?month=' + encodeURIComponent(month) +
        '&vendorCode=' + encodeURIComponent(vendorCode),
        null,
        'GET',
        function (data) {

            // Clear existing options + default option
            $('#ddlPONo').empty().append('<option value="">Select PO Number</option>');

            $.each(data, function (i, p) {
                $('#ddlPONo').append(
                    $('<option>', {
                        value: p.value,
                        text: p.text
                    })
                );
            });

            $('#trSearch').show();
        },
        null,   // error callback (optional)
        null,   // complete callback
        true,   // async
        false   // no loader (dropdown scenario)
    );
    }

    // ── Search ────────────────────────────────────────────────────────────
    function SearchReport() {
        var month      = $('#ddlMonth').val();
        var vSel       = $('#ddlVendor');
        var poSel      = $('#ddlPONo');
        var vendorCode = vSel.val();
        var vendorText = vSel.find('option:selected').text();
        var poVal      = poSel.val();
        var poText     = poSel.find('option:selected').text();
        var rateSeq    = poText; 

        if (!month || !vendorCode || !poVal) {
            showMessage('Please select Month, Vendor and PO Number.',true);
            return;
        }

        _searchCtx = {
            SelectedMonth:      month,
            SelectedVendorCode: vendorCode,
            SelectedVendorText: vendorText,
            SelectedPOValue:    poVal,
            SelectedPOText:     poText,
            SelectedPORateSeq:  rateSeq,
            DebitReason:        ''
        };

ExtendedAjaxCall(
    '/Reports/Search',
    _searchCtx, // data
    'POST',
    function (res) {

        if (!res.flag) {
            showMessage(res.msg || 'No data found.', true);
            return;
        }

        ClearMsg();

        // Fill detail labels
        $('#lblHeader').text(res.header);
        var d = res.details;

        $('#lblPONo').text(d.poNumber);
        $('#lblRateRev').text(d.rateSequence);
        $('#lblPoEffectFrom').text(d.poEffectFrom);
        $('#lblPOEffectTo').text(d.poEffectTo);
        $('#lblVendorCode').text(d.vendorCode);
        $('#lblVendorName').text(d.vendorName);
        $('#lblResCount').text(d.noOfUnits);
        $('#lblMonthDays').text(d.totalMonthDays);
        $('#lblPayableDays').text(d.payableDays);
        $('#lblTotalWorkingDays').text(d.totalWorkingDays);

        // Totals
        $('#lblNet').text(res.totalCredit);
        $('#lblDebit').text(res.totalDebit);
        $('#lblDebitCompany').text(res.compDebit);
        $('#lblGrand').text(res.netPayable);
        $('#txtDebitReason').val(res.debitReason).prop('disabled', res.isGenerated);

        // Grid
        var html = '';

        $.each(res.gridRows, function (i, row) {
            html += '<tr>'
                + '<td>' + (row.f_ResourceName || '') + '</td>'
                + '<td>' + (row.f_GradeCode || '') + '</td>'
                + '<td>' + (row.f_GradeMonthlyPOValue || '') + '</td>'
                + '<td>' + (row.f_MaxFixedAmount || '') + '</td>'
                + '<td>' + (row.f_MaxVariablePercentage || '') + '</td>'
                + '<td>' + (row.f_MaxVariableAmount || '') + '</td>'
                + '<td>' + (row.f_ActualVariablePercentage || '') + '</td>'
                + '<td>' + (row.f_ActualVariableAmount || '') + '</td>'
                + '<td>' + (row.f_PayableDays || '') + '</td>'
                + '<td>' + (row.f_PresentWorkingDays || '') + '</td>'
                + '<td>' + (row.f_PaidDays || '') + '</td>'
                + '<td>' + (row.f_PerDayCost || '') + '</td>'
                + '<td>' + (row.f_CreditAmount || '') + '</td>'
                + '<td>' + (row.f_DebitResource || '') + '</td>'
                + '<td>' + (row.f_NetPayable || '') + '</td>'
                + '</tr>';
        });

        $('#tReportGrid').html(html);
        $('#tblReportGrid').show();

        // Actions
        BuildActionButtons(res.isGenerated, res.showCovering);

        $('#pnlDetails').show();
    },
    null,
    null,
    true,
    true // loader ON (important for heavy API)
);
    }

    // ── Build Generate / Export buttons based on search result state ───────
    function BuildActionButtons(isGenerated, showCovering) {
        var html = '';
        if (!isGenerated) {
            html += '<button type="button" class="button" id="btnGenerate" onclick="GenerateReport()">Generate</button>&nbsp;';
        }
        if (isGenerated) {
            html += '<button type="button" class="button" id="btnExport" onclick="ExportInvoice()">Export To Invoice</button>&nbsp;';
            if (showCovering) {
                html += '<button type="button" class="button" id="btnExportCovering" onclick="ExportCovering()">Export To Covering Letter</button>';
            }
        }
        $('#divActions').html(html);
    }

    // ── Generate (AJAX) ───────────────────────────────────────────────────
    function GenerateReport() {
        _searchCtx.DebitReason = $('#txtDebitReason').val();
        $('#btnGenerate').prop('disabled', true).text('Processing...');
    ExtendedAjaxCall(
        '/Reports/Generate',
        _searchCtx, // data
        'POST',
        function (res) {

            if (res.flag) {
                showMessage('Generated successfully. Proceed with Export!', false);
                BuildActionButtons(true, res.hasCovering);
            } else {
                showMessage(res.msg || 'Generate failed.',true);
                $('#btnGenerate').prop('disabled', false).text('Generate');
            }
        },
        function () { // error callback
            showMessage('An error occurred during Generate.', true);
            $('#btnGenerate').prop('disabled', false).text('Generate');
        },
        null,
        true,
        true // loader ON (important for generate action)
    );
    }

    // ── Export Invoice (standard form POST — file download) ───────────────
    function ExportInvoice() {
        FillExportForm('frmExportInvoice', 'hExp');
        $('#frmExportInvoice').submit();
    }

    // ── Export Covering Letter (standard form POST — file download) ────────
    function ExportCovering() {
        FillExportForm('frmExportCovering', 'hCov');
        $('#frmExportCovering').submit();
    }

    function FillExportForm(formId, prefix) {
        $('#' + prefix + 'Month').val(_searchCtx.SelectedMonth);
        $('#' + prefix + 'VendorCode').val(_searchCtx.SelectedVendorCode);
        $('#' + prefix + 'VendorText').val(_searchCtx.SelectedVendorText);
        $('#' + prefix + 'POValue').val(_searchCtx.SelectedPOValue);
        $('#' + prefix + 'POText').val(_searchCtx.SelectedPOText);
        $('#' + prefix + 'RateSeq').val(_searchCtx.SelectedPORateSeq);
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    function ShowMsg(msg, type) {
        $('#divMsg').html('<span style="color:' + (type === 'success' ? 'green' : type === 'warning' ? 'orange' : 'red')
            + '; font-family:Verdana; font-size:10pt;">' + msg + '</span>');
    }
    function ClearMsg() { $('#divMsg').html(''); } 
