  function onCategoryChange(category) {
        $('#divGrid').hide();
        $('#divExportBtn').hide();
        $('#divMsg').html('');
        if (!category || category === '0') return;

        $.ajax({
            url: '/Reports/BindGrid?selectedCategory=' + encodeURIComponent(category),
            type: 'GET',
            success: function (res) {
                if (!res.flag) {
                    $('#divMsg').html('<div class="alert alert-warning">' + (res.msg || 'No record found !!!') + '</div>');
                    return;
                }

                // Build header from first row keys
                var firstRow = res.data[0];
                var headerHtml = '<tr>';
                $.each(firstRow, function (key) {
                    headerHtml += '<th class="py-3 px-4 border-0 text-nowrap">' + key + '</th>';
                });
                headerHtml += '</tr>';
                $('#tGridHeader').html(headerHtml);

                // Build rows
                var bodyHtml = '';
                $.each(res.data, function (i, row) {
                    bodyHtml += '<tr>';
                    $.each(row, function (key, val) {
                        bodyHtml += '<td class="py-3 px-4 border-bottom text-muted">' + (val !== null ? val : '') + '</td>';
                    });
                    bodyHtml += '</tr>';
                });
                $('#tGridBody').html(bodyHtml);

                $('#divGrid').show();
                $('#divExportBtn').show();
            },
            error: function () {
                $('#divMsg').html('<div class="alert alert-danger">An error occurred while loading data.</div>');
            }
        });
    }