function onCategoryChange(category) {
    // 1. Reset UI State
    $('#divGrid').hide();
    $('#divExportBtn').hide();
    $('#divMsg').html('');

    if (!category || category === '0') return;

    // Optional: Show a small spinner/loading message here if the network is slow
    $('#divMsg').html('<div class="text-muted small px-2"><i class="fas fa-spinner fa-spin"></i> Loading employee data...</div>');

   ExtendedAjaxCall(
    '/Reports/BindGrid?selectedCategory=' + encodeURIComponent(category),
    null,
    'GET',
    function (res) {
        $('#divMsg').html(''); // Clear loading msg

        if (!res.flag || !res.data || res.data.length === 0) {
            $('#divMsg').html(
                '<div class="alert alert-warning border-0 shadow-sm">' +
                (res.msg || 'No record found !!!') +
                '</div>'
            );
            return;
        }

        // Helper to format "EMP_CODE" to "Emp Code"
        const formatHeader = (text) =>
            text.replace(/_/g, ' ')
                .toLowerCase()
                .split(' ')
                .map(s => s.charAt(0).toUpperCase() + s.substring(1))
                .join(' ');

        // Build Headers
        var firstRow = res.data[0];
        var headerHtml = '';

        $.each(firstRow, function (key) {
            headerHtml += `
                <th class="py-3 px-4 text-uppercase fw-bold text-muted small border-bottom"
                    style="letter-spacing: 0.5px; white-space: nowrap;">
                    ${formatHeader(key)}
                </th>`;
        });

        $('#tGridHeader').html(headerHtml);

        // Build Rows
        var bodyHtml = '';

        $.each(res.data, function (i, row) {
            bodyHtml += '<tr class="align-middle">';

            $.each(row, function (key, val) {
                var displayVal = (val !== null && val !== undefined && val !== "")
                    ? val
                    : '<span class="text-muted opacity-50 small italic">N/A</span>';

                var cellClass = key.toLowerCase().includes('code')
                    ? 'fw-bold text-dark'
                    : 'text-secondary';

                bodyHtml += `<td class="py-3 px-4 border-bottom ${cellClass}">${displayVal}</td>`;
            });

            bodyHtml += '</tr>';
        });

        $('#tGridBody').html(bodyHtml);

        // Show UI
        $('#divGrid').fadeIn(400);
        $('#divExportBtn').show();
    },
    function (xhr) { // error callback
        console.error("Grid Load Error:", xhr);
        $('#divMsg').html(
            '<div class="alert alert-danger border-0 shadow-sm">' +
            'An error occurred while fetching the list. Please try again.' +
            '</div>'
        );
    },
    null,   // complete callback (not needed here)
    true,   // async (recommended)
    true    // show loader
);
}